<header class="main-header">
    <h1>Selamat Datang, User</h1>
</header>
