<aside class="col-md-3 sidebar">
    <h2>User Dashboard</h2>
    <ul class="nav-links">
        <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="mobil.php"><i class="fas fa-car"></i> Mobil</a></li>
        <li><a href="reservasi.php"><i class="fas fa-calendar-alt"></i> Reservasi</a></li>
        <li><a href="logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
    </ul>
</aside>
